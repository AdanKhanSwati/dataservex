import type { Metadata } from "next";
import { PageHero } from "@/components/sections/PageHero";
import { AboutSection } from "@/components/sections/AboutSection";
import { ApproachSection } from "@/components/sections/ApproachSection";
import { OnePartnerSection } from "@/components/sections/OnePartnerSection";
import { ResultsSection } from "@/components/sections/ResultsSection";
import { FinalCtaSection } from "@/components/sections/FinalCtaSection";
import { about } from "@/lib/content";

export const metadata: Metadata = {
  title: "About Us",
  description: about.paragraphs.join(" "),
};

export default function AboutPage() {
  return (
    <>
      <PageHero eyebrow={about.eyebrow} headline={about.headline} highlight={["Results."]} />
      <AboutSection showHead={false} />
      <ApproachSection />
      <OnePartnerSection />
      <ResultsSection />
      <FinalCtaSection />
    </>
  );
}
