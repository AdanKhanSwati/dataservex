import { Hero } from "@/components/sections/Hero";
import { CapabilityMarquee } from "@/components/sections/CapabilityMarquee";
import { WhyUsSection } from "@/components/sections/WhyUsSection";
import { ServiceIndex } from "@/components/sections/ServiceIndex";
import { FieldServicesSection } from "@/components/sections/FieldServicesSection";
import { FieldPartnershipsSection } from "@/components/sections/FieldPartnershipsSection";
import { IndustriesSection } from "@/components/sections/IndustriesSection";
import { SolutionsSection } from "@/components/sections/SolutionsSection";
import { AboutSection } from "@/components/sections/AboutSection";
import { ApproachSection } from "@/components/sections/ApproachSection";
import { OnePartnerSection } from "@/components/sections/OnePartnerSection";
import { ResultsSection } from "@/components/sections/ResultsSection";
import { FinalCtaSection } from "@/components/sections/FinalCtaSection";

export default function Home() {
  return (
    <>
      <Hero />
      <CapabilityMarquee />
      <WhyUsSection />
      <ServiceIndex />
      <FieldServicesSection />
      <FieldPartnershipsSection />
      <IndustriesSection />
      <SolutionsSection />
      <AboutSection />
      <ApproachSection />
      <OnePartnerSection />
      <ResultsSection />
      <FinalCtaSection />
    </>
  );
}
