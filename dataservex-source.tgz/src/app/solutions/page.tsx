import type { Metadata } from "next";
import { PageHero } from "@/components/sections/PageHero";
import { SolutionsSection } from "@/components/sections/SolutionsSection";
import { OnePartnerSection } from "@/components/sections/OnePartnerSection";
import { FinalCtaSection } from "@/components/sections/FinalCtaSection";
import { solutions } from "@/lib/content";

export const metadata: Metadata = {
  title: "Solutions",
  description: solutions.headline,
};

export default function SolutionsPage() {
  return (
    <>
      <PageHero
        eyebrow={solutions.eyebrow}
        headline={solutions.headline}
        highlight={["Business"]}
      />
      <SolutionsSection showHead={false} />
      <OnePartnerSection />
      <FinalCtaSection />
    </>
  );
}
